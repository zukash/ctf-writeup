import os

FLAG = os.environ.get("FLAG", "flag{FAKE}")
